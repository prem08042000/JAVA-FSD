package com;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the doctor id to check the appointment");
		int id = sc.nextInt();
		
		Appointment a = new Appointment();
		
		try {
			a.BookAppointment(id);
			
		} catch (DoctorNotFound e) {
			System.out.println(e.getMessage());
		}
	}

}
