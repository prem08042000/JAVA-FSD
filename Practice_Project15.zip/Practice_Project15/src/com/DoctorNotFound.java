package com;

public class DoctorNotFound extends Exception{
	String message;
	
	DoctorNotFound(String message){
		super(message);
	}
		
}
