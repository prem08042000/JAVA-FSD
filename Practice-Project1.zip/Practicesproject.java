package project;

public class Practicesproject {

	public static void main(String[] args) {
		//IMPLICIT TYPE CASTING
		 int num = 10;
		    System.out.println("The integer value: " + num);
		    double data = num;
		    System.out.println("The double value: " + data);
		  //EXPLICIT TYPE CASTING
		    double N = 10.99;
		    System.out.println("The double value: " + N);

		    // convert into int type
		    int value = (int)num;
		    System.out.println("The integer value: " + value);

	}

}
