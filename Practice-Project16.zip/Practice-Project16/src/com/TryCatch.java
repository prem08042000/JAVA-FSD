package com;
import java.util.Scanner;
import java.util.*;
public class TryCatch {

	public static void main(String[] args) {
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter a the first divident");
			int n1 = sc.nextInt();
			System.out.println("Enter the divisor");
			int n2 = sc.nextInt();
			System.out.println(n1/n2);
		}
		catch(InputMismatchException e) {
			
			System.out.println("Error: " + e);
			System.out.println("!!!!!!The input type can only be integer not of any other type!!!!!!");
			
		}
		
		catch(ArithmeticException e) {
			
			System.out.println("Error: " + e);
			System.out.println("!!!!!!The divisor can not be zero!!!!!!");
			
		}
		
	}

}
