package com;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.List;

public class FileOperations {
	
		public static void createFile() {
	          File file = new File("D:\\Mphasis Assignments\\testFile1.txt");
	          
	          try {
				if(file.createNewFile()) {
					  System.out.println("File is created!");  
				  }
				  else {
					  System.out.println("File already exists.");
				  }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

		}
		
		public static void readFile() {
			List<String> content = null;
			String str = "D:\\Mphasis Assignments\\Study SFMC.txt";
			try {
				content = Files.readAllLines(Paths.get(str));

				for(String s : content) {
					System.out.println(s);
				}
			} catch (IOException e) {
				System.out.println("Something Error");
			}
		}
		
		public static void writeFile() {
			
			String str = "D:\\Mphasis Assignments\\WrittenFile.txt";
			FileWriter fw= null;
			
			try {
				fw = new FileWriter(str, true);
				fw.write("Appending this line");
				System.out.println("Success");
			} catch (IOException e) {
				System.out.println("Something Went Wrong");
			}
			finally {
				try {
					fw.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
			
		}
				
		public static void updateFile() {

	        File fileToBeModified = new File("D:\\Mphasis Assignments\\UpdateFile.txt");
	        String oldContent = "";
	        BufferedReader reader = null;
	        FileWriter writer = null;
	        try
	        {
	            reader = new BufferedReader(new FileReader(fileToBeModified));
	            String line = reader.readLine();
	            while (line != null) 
	            {
	                oldContent = oldContent + line + System.lineSeparator();
	                line = reader.readLine();
	            }
	            String newContent = oldContent.replaceAll("Apple", "Strawberry");
	            writer = new FileWriter(fileToBeModified);
	            writer.write(newContent);
	            
	            System.out.println("Success");
	        }
	        catch (IOException e)
	        {
	        	System.out.println("Something went wrong");
	        }
	        catch(Exception e) {
	        	System.out.println("Something went wrong");
	        }
	        finally
	        {
	            try
	            {
	                reader.close();
	                writer.close();
	            } 
	            catch (Exception e) 
	            {
	            	System.out.println("Something went wrong");
	            }
	        }

		}
		
		
		public static void deleteFile() {
		    { 
		        try
		        { 
		            Files.deleteIfExists(Paths.get("D:\\Mphasis Assignments\\DeleteFile.txt")); 
		            System.out.println("Deletion successful."); 
		        } 
		        catch(NoSuchFileException e) 
		        { 
		            System.out.println("No such file/directory exists"); 
		        } 
		        catch(IOException e) 
		        { 
		            System.out.println("Invalid permissions."); 
		        } 
		        System.out.println("Done"); 
		    } 

		}
}





















