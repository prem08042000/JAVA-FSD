package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter which of the below operation you want to do: ");
		System.out.println("1. Create File");
		System.out.println("2. Read File");
		System.out.println("3. Update File");
		System.out.println("4. Delete File");
		int choice = sc.nextInt();
		switch(choice) {
		case 1: 
			FileOperations.createFile();
			break;
		case 2: 
			FileOperations.readFile();
			break;
		case 3: 
			FileOperations.updateFile();
			break;
		case 4: 
			FileOperations.deleteFile();
			break;
		}
		

	}

}
