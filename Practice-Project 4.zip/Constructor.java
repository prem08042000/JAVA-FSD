package Project4;

public class Constructor {

	public static void main(String[] args) {
Constructor ct = new Constructor();
		
		Constructor ct1 = new Constructor("Ok");
		
		Constructor ct3 = new Constructor(2, 3);
		
		Constructor ct4 = new Constructor(4, 5, "Value");
		
	}
		Constructor(){
			System.out.println("This is No-Argument Constructor");
		}
		
		Constructor(String str){
			System.out.println(str);
			System.out.println("This is Parameterized Constructor");
		}
		
		//The below two constructor are parametrized overloaded constructor
		
		Constructor(int x, int y){
			System.out.println("The sum of two number is: " + (x+y));
		}
		Constructor(int x, int y , String str){
			System.out.println("The multiplication " + str + (x*y));
		}
	
	

	
	}

