
public class methodcalling {

	
	void methodcall() 
	{
		System.out.println("welcome");
	}
	
	public static void main(String[] args) {
		methodcalling sc=new methodcalling();
		sc.methodcall();
		

	}

}
