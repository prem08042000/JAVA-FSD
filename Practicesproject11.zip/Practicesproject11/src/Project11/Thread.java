package Project11;

public class Thread {
	public void run()
 	{
  		System.out.println("concurrent thread started running..");
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread mt = new  Thread();
  		mt.start();

	}


	public void start() {
		// TODO Auto-generated method stub
		
	}


	public static void sleep(int i) {
		// TODO Auto-generated method stub
		
	}

}
