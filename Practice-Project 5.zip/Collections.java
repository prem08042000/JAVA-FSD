package Project5;
import java.util.*;
public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList Collection type
				ArrayList <Integer> list = new ArrayList <Integer>();
				
				//Adding values in the list
				list.add(11);
				list.add(89);
				list.add(56);
				list.add(93);
				list.add(43);
				
				//Printing the list values
				for(Integer a : list) {
					System.out.print(a+ " ");
				}
				System.out.println();
				
				//Removing the value at any index
				list.remove(2);
				System.out.println("After removing the element at index 2");
				for(Integer a : list) {
					System.out.print(a + " ");
				}
				
			}

	}


