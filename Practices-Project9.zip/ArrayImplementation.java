package com;

public class ArrayImplementation {
	public static void main(String[] args) {
		
		int array1[] = {21, 11, 54, 67, 96}; //Array Declaration and Initiallization
		
		int array2[] = new int[5]; // Array Declaration and Instantiation
		array2[0] = 21;
		array2[1] = 54;
		array2[2] = 98;
		array2[3] = 25;
		array2[4] = 67;
		
		//Printing the array
		for(int i = 0; i < array1.length; i++) {
			System.out.println(array1[i]);
		}
		
		
		//2 Dimensional Array
		
		int array3[][] = {{32, 78, 87}, {62, 78, 90}, {11, 89, 74}};
		
		//Printing 2D array
		for(int i = 0; i < array3.length; i++) {
			
			for(int j = 0; j < array3.length; j++) {
				System.out.print(array3[i][j] + " ");
			}
			System.out.println();
		}
		
		
	}
}
