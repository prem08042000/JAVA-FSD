package pkg1;

public  class B {
	 
	  	 private int  i=23;
	  	protected int  g=10;	
	   int v=5;
	  	
void meth2()
{
	System.out.println(c.p);
	//System.out.println(c.x);//not acceced due to private
	}	
}
	  	 
	   
	   
	   
	  
	   


		
		 
		 
	 
	 
	 
		
	 



