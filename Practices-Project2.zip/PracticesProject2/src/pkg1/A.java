package pkg1;

 public class A {
	 public static void main(String[] args) {
       c sc =new c();
      sc.meth1();
       B kc=new B();
       //System.out.println(kc.v);
       //System.out.println(kc.g);
       //System.out.println(kc.i);
       kc.meth2();
	}
	 
	 
 }
 
 
	 class c{
	 private int x=5;
	public int y=45;

	protected int z = 10;

	public static int p = 100;
	public void meth1() {
		//always access in the same class
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		System.out.println(p);
		
	}
	}
 

