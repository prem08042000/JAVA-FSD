package Project29;
import java.util.LinkedList;
public class Prema {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> queue = new LinkedList<>();

        // enqueue elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);

        // print the queue
        System.out.println("Queue: " + queue);

        // dequeue an element from the queue
        queue.remove();

        // print the queue
        System.out.println("Queue after dequeuing: " + queue);

        // enqueue more elements into the queue
        queue.add(40);
        queue.add(50);

        // print the queue
        System.out.println("Queue after enqueuing: " + queue);
    }
	}


