package pkg2;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class emaildemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String email;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Please enter email-id :");
		email=scanner.nextLine();
		//String email; //= "aksingh@yahoo.co.in";
		String emailRegex = "^[a-zA-Z0-9_.-]+@(.+)$";
		Pattern emailPattern = Pattern.compile(emailRegex);
		Matcher emailMatcher = emailPattern.matcher(email);
		
		if(emailMatcher.matches())
		System.out.println("\n The given text is a valid email");
		else System.out.println("\n The given text is NOT a valid email");
		
	}

}
