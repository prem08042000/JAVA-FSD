package com;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegularExpression {

	public static void main(String[] args) {
		String pattern = "[789][0-9]{9}";
		String matcher = "8384738383";
		
		
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(matcher);
		
		if(m.matches()) {
			System.out.println("Matched");
		}
		else {
			System.out.println("Not Matched");
		}

	}

}
