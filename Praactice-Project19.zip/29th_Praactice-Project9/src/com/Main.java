package com;

public class Main {

	public static void main(String[] args) {
		
		DemoInterface di = new DemoInterface();
		
		di.show();
		
		
		//To solve the diamond problem we use the interface Name to access the method
		interfaceB.announce();
		

	}

}
