package com;

import com.interfaceA;
import com.interfaceB;

interface interfaceA {
	
	public abstract void show();
	
	public static void announce() {
		System.out.println("Announcement interfaceA");
	}
}

interface interfaceB{
 public abstract void show();
 
 public static void announce() {
	 System.out.println("Announcement interfaceB");
 }
}

public class DemoInterface implements interfaceA, interfaceB {
		
		public void show() {
			System.out.println("Show method");
		}
}
