package Project7;

public class InnerclassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//To access the inner static class we need to write in below format
		InnerclassDemo.Class1 oc1 = new InnerclassDemo.Class1();
				oc1.display1();
				
				//To access the inner non-static we have to create the object of outer class and after that using that object we have to create the object for the inner class
				InnerclassDemo oc2 = new InnerclassDemo();
				InnerclassDemo.Class2 c2 = oc2.new Class2();
				c2.display2();
				
				//Accessing the private inner class will result in error
				InnerclassDemo oc3 = new InnerclassDemo();
				//OutsideClass.Class3 c3 = oc3.new Class3(); // Error because the inner class is private
	}
	public static class Class1{	
		public void display1() {
			System.out.println("Static Class Member");
		}
	}
	
	public class Class2{	
		public void display2() {
			System.out.println("Non-Static Class Member");
		}
	}
	
	private class Class3{
		public void display3() {
			System.out.println("Non-Static Class Member(Private)");
		}
	}
}
