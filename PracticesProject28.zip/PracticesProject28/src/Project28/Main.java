package Project28;
import java.util.Stack;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		        // create a stack
		        Stack<Integer> stack = new Stack<>();

		        // push elements into the stack
		        stack.push(10);
		        stack.push(20);
		        stack.push(30);

		        // print the stack
		        System.out.println("Stack: " + stack);

		        // pop elements from the stack
		        stack.pop();

		        // print the stack
		        System.out.println("Stack after popping: " + stack);

		        // push elements into the stack
		        stack.push(40);
		        stack.push(50);

		        // print the stack
		        System.out.println("Stack after pushing: " + stack);
		    }
	}


