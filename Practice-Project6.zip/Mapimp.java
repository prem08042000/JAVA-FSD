package Project6;
import java.util.*;
import java.util.Map;
import java.util.Map.Entry;
public class Mapimp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Map<Integer, String> m = new HashMap<>();
			
			m.put(1, "Ram");
			m.put(2, "Rajesh");
			m.put(3, "Mohit");
			m.put(4, "Nikhil");
			m.put(5, "Subham");
			
			for(Entry<Integer, String> i : m.entrySet()) {
				System.out.println("Key: " + i.getKey() + "  " + "Value: " + i.getValue());
			}

	}

}
