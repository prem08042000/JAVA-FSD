package Project31;

public class ExponentialSearch {

    public static int exponentialSearch(int[] arr, int key) {
        if (arr[0] == key) {
            return 0;
        }

        int i = 1;
        while (i < arr.length && arr[i] <= key) {
            i = i * 2;
        }

        return binarySearch(arr, i / 2, Math.min(i, arr.length - 1), key);
    }

    public static int binarySearch(int[] arr, int left, int right, int key) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == key) {
                return mid;
            }
            if (arr[mid] < key) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {2, 3, 4, 10, 40};
        int key = 10;
        int result = exponentialSearch(arr, key);
        if (result != -1) {
            System.out.println("Element found at index " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
